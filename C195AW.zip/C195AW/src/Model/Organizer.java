package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 ** Description This Creates an Inventory Class.JAVA SE should work if you update any feature in this page
 ** @author Ayinde
 */
public class Organizer {
      /**
     ** RecordsGen was used to generate a unique Id for Record, otherwise we had a logic error  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  **a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
   public static int recordidGeneration;
     /**
     *  AppointmentGen same basics as the RecordsGen, creating a unique ID  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
   public static int appointmentidGeneration;
     /**
     *   allRecords was an observable list created to work with Modify Record a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static ObservableList<Record> allRecords = FXCollections.observableArrayList();
     /**
     *   allAppointments was an observable list created to work with Modify Appointment a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();
     /**
     *  lookupRecords was a method  created to work with the Search functions,  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    private static ObservableList<Record> lookupRecord = FXCollections.observableArrayList();
      /**
     *   lookupAppointment was a method created to work with search functions to avoid logic errors a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
     private static ObservableList<Appointment> lookupAppointment = FXCollections.observableArrayList();
    public static void AddRecord(Record NewRecord) {
        allRecords.add(NewRecord);
    }

    public static void AddAppointment(Appointment NewAppointment) {
        allAppointments.add(NewAppointment);
    }

    public static Record lookupRecords(int RecordPiece) {
      if (!allRecords.isEmpty()) {
            for (int i = 0; i < allRecords.size(); i++) {
                if (allRecords.get(i).getrecordId() == RecordPiece) {
                    return allRecords.get(i);
                }
            }

        }
        return null;
    }


    
    
    
    
    
    
    
    
        /**
         * lookup Record required a retool,because it kept causing a runtime error, I fixed it using the made up "eo" variable to get the search working
 should work with Java SE 
         * @param RecordsName
         * @return
         */
    public static final ObservableList<Record> lookupRecords (String RecordsName) {
         ObservableList<Record> eo = FXCollections.observableArrayList();
           

        for (Record dn : allRecords)
           {
        if (RecordsName.compareTo(dn.getName())==0)
                { eo.add(dn);
                     }
        }   
        return eo;
    }
    
    



public static Appointment lookupAppointment(int Appointmentid) {
        for(Appointment cm: allAppointments) {
           if(cm.getappointmentId() == Appointmentid){
               
           return cm;}
        }return null;}

/**
         *
         * @param AppointmentName
         * @return
         */

 public static ObservableList<Appointment> lookupAppointment(String AppointmentName) {
        return allAppointments.sorted();   
} 
   /**
     *  updateRecords, created to power the Modify Record function a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static void updateRecords(int index, Record selectedRecords) {
        allRecords.set(index, selectedRecords);
    }
  /**
     *  updateAppointments was a method created to power Modify Appointment a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static void updateAppointment(int index, Appointment selectedAppointment) {
        allAppointments.set(index, selectedAppointment);
    }
  /**
     * deleteRecords was created to power the Drelte Record button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static boolean deleteRecord(Record selectedRecords){
        return allRecords.remove(selectedRecords);
}
/**
     *   deleteAppointment was created to power the Delete Appointment button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static boolean deleteAppointment(Appointment selectedAppointment){
        return allAppointments.remove(selectedAppointment);
}
/**
     *  GetAllAppointments was created to work with the Modify Appointment field detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static ObservableList<Appointment> GetAllAppointments(){
           return allAppointments;
               }
/**
     *   GetAllRecords was created to work with Modify Record detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static ObservableList<Record> GetAllRecords() {
        return allRecords; //To change body of generated methods, choose Tools | Templates.
    }
    
    /**
     *   works with RecordsGen detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
     public static int getRecordidGeneration(){
        recordidGeneration++;
        return recordidGeneration;
    }
     /**
     *   works with RecordsGen detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
     public static int getAppointmentidGeneration(){
        appointmentidGeneration++;
        return appointmentidGeneration;
    }
}







    /**/
