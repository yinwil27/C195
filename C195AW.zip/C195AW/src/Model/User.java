/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Wakiti
 */
public class User {
    int userid;
    String UserName;
  public User(int userid, String UserName) {
        this.userid = userid;
        this.UserName = UserName;
    }

    public int getUserid() {
        return userid;
    }

    public String getUserName() {
        return UserName;
    }
 @Override 
    public String toString()
            
    {
    return UserName;
    }
}



