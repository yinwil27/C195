/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import Model.User;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */
//repeat for all combo boxes
public class DBUser {

    public static ObservableList<User> GetAllUsers() {
        ObservableList<User> DBListofUsers = FXCollections.observableArrayList();
        try {
            String SQL = "Select User_ID, User_Name FROM users";
            PreparedStatement PS = DBConnection.getConnection().prepareStatement(SQL);
            ResultSet RS = PS.executeQuery();
            while (RS.next()) {
                int User_ID = RS.getInt("User_ID");
                String User = RS.getString("User_Name");
                User u = new User(User_ID, User);
                DBListofUsers.add(u);
            }

        } catch (SQLException a) {
            a.printStackTrace();
        }

        return DBListofUsers;
    }

}
