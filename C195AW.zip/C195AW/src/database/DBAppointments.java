/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import Model.Appointment;
import Model.Customer;
import java.sql.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */

    
public class DBAppointments {

    public static ObservableList<Appointment> GetAllAppointment() {
        ObservableList<Appointment> DBListofAppointments = FXCollections.observableArrayList();
        try {
            String SQL =" SELECT Appointment_ID, Title, Description, Location, Type, Start, End, appointments.Customer_ID,  Customer_Name, users.User_ID, User_Name, contacts.Contact_ID, Contact_Name FROM appointments, customers, users, contacts WHERE appointments.Customer_ID = customers.Customer_ID AND appointments.User_ID = users.User_ID AND appointments.Contact_ID = contacts.Contact_ID";


  /*Appointment(int Appointment_ID, String Created_By,  String Title, String Description,
            String Location, int Contact_ID, String Type, LocalDate Create_Date, LocalTime Start,
            LocalTime End, 
             int Customer_ID,  int User_ID)  */
            PreparedStatement PS = DBConnection.getConnection().prepareStatement(SQL);
            ResultSet RS = PS.executeQuery();
            while (RS.next()) {
                int Appointment_ID = RS.getInt("Appointment_ID");
                String Title = RS.getString("Title");
                String Description = RS.getString("Description");
                String Type = RS.getString("Type");
                Timestamp Start = RS.getTimestamp("Start");
                LocalDateTime StartLDT = Start.toLocalDateTime();//timezone conversion
                LocalTime StartTime = StartLDT.toLocalTime();
                LocalDate Date = StartLDT.toLocalDate();
                Timestamp End = RS.getTimestamp("End");// Repeat everything I did on START
                
                LocalDateTime EndLDT = End.toLocalDateTime();//timezone conversion
                LocalTime EndTime = EndLDT.toLocalTime();
                LocalDate EndDate = EndLDT.toLocalDate();
               String CustomerName = RS.getString("Customer_Name");
               String UserName = RS.getString("User_Name");
               String ContactName = RS.getString("Contact_Name");
                String Location = RS.getString("Location");
                int User_ID = RS.getInt("User_ID");
                int Customer_ID = RS.getInt("Customer_ID");
                int Contact_ID = RS.getInt("Contact_ID");
      
              Appointment a = new Appointment( Appointment_ID, Title, Description,   Location,  Type, Date,  StartTime, EndTime, ContactName,   Customer_ID,   User_ID, Contact_ID ) ;
DBListofAppointments.add(a);

        } 
        
        }catch (SQLException a) {
            a.printStackTrace();
        }

        return DBListofAppointments;
    }
    public static void createAppointment(Appointment TemplateAppointment) {
        // look up key to keys and "insert" to make everything work; //To change body of generated methods, choose Tools | Templates.
String sql = "INSERT INTO appointments Values(NULL, ?, ?,?,Now(),?,?,?,?,NULL,NULL,NULL)"; 
       // (Appointment_ID,Title,Description, Type, Phone, Division_ID) VALUES (5, '', 'test', '', 'test','')" ;
       
        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setString(1, TemplateAppointment.getTitle());
            ps.setString(2, TemplateAppointment.getDescription());
            ps.setString(3, TemplateAppointment.getType());
           // ps.setTimestamp(4, TemplateAppointment.);
            ps.setString(5, TemplateAppointment.getCustomerName());
             ps.setString(6, TemplateAppointment.getUserName());
              ps.setString(7, TemplateAppointment.getContactName());
               ps.setString(8, TemplateAppointment.getLocation());
                ps.setInt(9, TemplateAppointment.getCustomerid());
                ps.setInt(10, TemplateAppointment.getUserid());
                ps.setInt(11, TemplateAppointment.getContactid());
           
            ps.execute();
          
        } catch (SQLException ex) {
        ex.printStackTrace();
        }

        
    }

}


