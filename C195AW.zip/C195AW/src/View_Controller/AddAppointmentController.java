/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Wakiti
 */
public class AddAppointmentController implements Initializable {

    @FXML
    private Button SaveButton;
    @FXML
    private Button CancelButton;
    @FXML
    private ComboBox<?> FirstLevelDivisionComboBox;
    @FXML
    private ComboBox<?> CountryComboBox;
    @FXML
    private TextField AppointmentTitleTextField;
    @FXML
    private TextField AppointmentDescriptionTextField;
    @FXML
    private TextField AppointmentLocationTextField;
    @FXML
    private TextField PhoneNumberAppointmentContactTextFieldTextField;
    @FXML
    private TextField AppointmentIDTextField;
    @FXML
    private TextField AppointmentTypeTextField;
    @FXML
    private TextField AppointmentStartDateAndTimeTextField;
    @FXML
    private TextField AppointmentEndDateAndTimeTextField;
    @FXML
    private TextField AppointmentCustomerIDTextField;
    @FXML
    private TextField AppointmentUserTextField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
