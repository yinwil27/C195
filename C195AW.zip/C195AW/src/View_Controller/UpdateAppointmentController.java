/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

//import Model.Organizer;
//import static Model.Organizer.GetAllAppointments;
import Model.Appointment;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import static View_Controller.CustomerMainScreenController.appointmentToModifyIndex;

/**
 * FXML Controller class
 *
 * @author Wakiti
 */
public class UpdateAppointmentController implements Initializable {

    @FXML
    private Button SaveButton;
    @FXML
    private Button CancelButton;
    @FXML
    private TextField AppointmentTitleTextField;
    @FXML
    private TextField AppointmentDescriptionTextField;
    @FXML
    private TextField AppointmentLocationTextField;
    @FXML
    private TextField AppointmentIDTextField;
    @FXML
    private ComboBox<?> FirstLevelDivisionComboBox;
    @FXML
    private ComboBox<?> CountryComboBox;
    @FXML
    private TextField AppointmentTypeTextField;
    @FXML
    private TextField AppointmentStartDateAndTimeTextField;
    @FXML
    private TextField AppointmentEndDateAndTimeTextField;
    @FXML
    private ComboBox<?> ContactComboBox;
    @FXML
    private ComboBox<?> AppointmentCustomerIDTComboBox;
    @FXML
    private ComboBox<?> AppointmentUserComboBox;

     Appointment TemporaryAppointment;
    private int appointmentIndex = appointmentToModifyIndex();
    private String exceptionMessage = new String();
    private int appointmentid;
    private TextField UpdateAppointmentsIDField;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    public void bringFromAddAppointment(Appointment Dyn){
     TemporaryAppointment = Dyn;
//         appointmentIndex = Organizer.GetAllAppointments().indexOf(Dyn);
  //      appointmentid = GetAllAppointments().get(appointmentIndex).getappointmentId();
        UpdateAppointmentsIDField.setText("Appointment ID autoset to: " + Dyn.getAppointment_ID());
        AppointmentTitleTextField.setText(Dyn.getTitle());
        AppointmentTypeTextField.setText(Dyn.getType());
        AppointmentLocationTextField.setText(Dyn.getLocation());
     

        AppointmentDescriptionTextField.setText(Dyn.getDescription());
    }
    
    void Save(ActionEvent event) throws IOException {
         
        
//         int appointmentid = Organizer.getAppointmentidGeneration();
     String title =AppointmentTitleTextField.getText();
      String location = AppointmentLocationTextField.getText();
     String StartDateAndTime = AppointmentStartDateAndTimeTextField.getText();
     String EndDateAndTime = AppointmentEndDateAndTimeTextField.getText();
     String type= AppointmentTypeTextField.getText();
     String description = AppointmentDescriptionTextField.getText();
        
        
        
       
       // TemporaryProduct  .deleteAssociatedPart(part);
        if (exceptionMessage.length() > 0) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error Adding Product");
            alert.setHeaderText("Error");
            alert.setContentText(exceptionMessage);
            alert.showAndWait();
            exceptionMessage = "";
        } else{
                Appointment newAppointment = null;
   /*             newAppointment.setappointmentId(appointmentid);
                newAppointment.setType(type);
                newAppointment.setDescription (description);
                newAppointment.setLocation(location);*/



                Parent productsSave = FXMLLoader.load(getClass().getResource("CustomerMainScreen.fxml"));
                Scene scene = new Scene(productsSave);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(scene);
                window.show();
        }
    } void Cancel(ActionEvent event) throws IOException {
       
 Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
       
        alert.setTitle("Double Check");
        alert.setHeaderText("Go Back?");
        alert.setContentText("you want to leave?");
        Optional<ButtonType> result = alert.showAndWait();

        
        if (result.get() == ButtonType.OK) {

            Parent partsCancel = FXMLLoader.load(getClass().getResource("/View_Controller/CustomerMainScreen.fxml"));
            Scene scene = new Scene(partsCancel);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        } else {
            System.out.println("You clicked cancel. Please complete part info.");
        }
        
        
        
        
        } 
}

    
  